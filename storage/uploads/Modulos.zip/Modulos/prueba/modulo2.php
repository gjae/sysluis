<?php

namespace App\Http\Controllers\Modulos\prueba;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class modulo2 extends Controller
{
    //
}
